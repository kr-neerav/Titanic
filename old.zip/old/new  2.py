X = numpy.loadtxt('X.csv',delimiter = ',')
y = numpy.loadtxt('y.csv',delimiter = ',')
Xt = numpy.loadtxt('Xt.csv',delimiter = ',')

def normal(X,j,val):
	for i in range(len(X)):
		X[i,j] = X[i,j]/val
		if X[i,j] < 0.33:
			X[i,j] =1
		elif X[i,j] <0.67:
			X[i,j] =2
		else:
			X[i,j] = 3
		
def newTrain(X,y, cnt):
	#X = numpy.loadtxt(f, delimiter = ',')
	for i in range(cnt):
		idx = []
		for j in range(len(X)):
			if random.random() < 0.6:
				idx.append(j)
		numpy.savetxt('train'+str(i)+'.csv', X[tuple(idx),:], delimiter = ',', fmt = '%i,%i,%10.3f,%i,%i,%10.3f,%i,%i,%i')
		numpy.savetxt('trainy'+str(i)+'.csv',y[idx], delimiter = ',', fmt = '%i')
	
	
def train():
	clfL = []
	for i in range(10):
		X = numpy.loadtxt('train'+str(i)+'.csv', delimiter = ',')
		y = numpy.loadtxt('trainy'+str(i)+'.csv', delimiter = ',')
		clf = svm.SVC(C = 100)
		clf.fit(X,y)
		clfL.append(clf)
	return clfL
	
def out(clf, Xt):
	prey = []
	fnl = []
	a = []
	for i in range(len(clf)):
		prey.append(clf[i].predict(Xt))
	for j in range(len(Xt)):
		sum = 0
		temp = []
		for i in range(len(prey)):
			sum = sum + prey[i][j]
			temp.append(prey[i][j])
		if sum > 5:
			fnl.append([1,sum])
		else:
			fnl.append([0,sum])
		a.append(temp)
	return a
		

def splitNeg(X,y, cnt):
	pos = []
	neg =[]
	for i in range(len(y)):
		if y[i] == 0:
			pos.append(i)
		else:
			neg.append(i)
	for i in range(cnt):
		idx = []
		for j in range(len(neg)):
			if random.random() < 0.4:
				idx.append(j)
		fnl = pos[:]
		fnl.extend(idx)
		numpy.savetxt('train'+str(i)+'.csv', X[tuple(fnl),:], delimiter = ',', fmt = '%i,%i,%10.3f,%i,%i,%10.3f,%i,%i,%i')
		numpy.savetxt('trainy'+str(i)+'.csv',y[fnl], delimiter = ',', fmt = '%i')
		
		
def trainNN(clf, X, y):
	prey = []
	for i in range(len(clf)):
		prey.append(clf[i].predict(X))
	prey = numpy.asarray(prey)
	prey = prey.T
	rbm = BernoulliRBM(learning_rate = 0.06, n_iter = 20, n_components = 0)
	rbm.fit(prey, y)
	return rbm
	
def out(clf, DT, Xt):
	prey = []
	fnl = []
	for i in range(len(clf)):
		prey.append(clf[i].predict(Xt))
	prey = numpy.asarray(prey)
	prey = prey.T
	return DT.predict(prey)
	
def trainDT(clf, X, y):
	prey = []
	for i in range(len(clf)):
		prey.append(clf[i].predict(X))
	prey = numpy.asarray(prey)
	prey = prey.T
	DT = DecisionTreeClassifier()
	DT.fit(prey, y)
	return DT
	
	
def trainSVC(clf, X, y):
	prey = []
	for i in range(len(clf)):
		prey.append(clf[i].predict(X))
	prey = numpy.asarray(prey)
	prey = prey.T
	s = svm.SVC()
	s.fit(prey, y)
	return s