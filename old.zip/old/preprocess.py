#############################################
#	this program preprocess the data		#
#	using scikit-learn modules				#
#############################################

from sklearn import preprocessing
import numpy
import sys
import csv
import json


def readData(csvf):
	"""to read all the contents of the file and store it in a list of lists"""
	dataset = []
	while(True):
		try:
			temp = csvf.next()
		except StopIteration:
			break
		dataset.append(temp)
	return dataset
	
def ColMissingValues(dataset, header, stats):
	"""print the column names with missing values.
	If header not present print the column indexes.
	It also converts the integer and float values to the respective datatypes.
	Also calculate stats for each column so we can generate missing value"""
	blankCol = {}
	for rec in dataset:
		id = 0
		for val in rec:
			if val == '':
				if id in blankCol:
					blankCol[id] = blankCol[id] + 1
				else:
					blankCol[id] = 1
			elif id == 1 or id == 2  or id == 6 or id == 7:
				rec[id] = int(rec[id])
				if rec[id] in stats[rec[1]][id]:
					stats[rec[1]][id][rec[id]] = stats[rec[1]][id][rec[id]]+1
				else:
					stats[rec[1]][id][rec[id]]=1
			elif id == 9 or id == 5:
				rec[id] = float(rec[id])
				stats[rec[1]][id][0] = stats[rec[1]][id][0] + rec[id]
				stats[rec[1]][id][1] = stats[rec[1]][id][1] + 1
			elif id == 4 or id == 11:
				if rec[id] in stats[rec[1]][id]:
					stats[rec[1]][id][rec[id]] = stats[rec[1]][id][rec[id]]+1
				else:
					stats[rec[1]][id][rec[id]]=1				
			id = id + 1
	for key in blankCol.keys():
		print key, header[key], blankCol[key]


def maxavg(defaults):
	"""to calculate default values max count for categorical variables
	and avg for continous variables"""
	for key in defaults.keys():
		if key == 5 or key == 9:
			defaults[key] = defaults[key][0]/defaults[key][1]
		else:
			mx = 0
			count = 0
			for k in defaults[key].keys():
				count = count + 1
				if defaults[key][k] > mx:
					mx = defaults[key][k]
					val = k
			if count > 0:
				defaults[key] = val
	return defaults
	
	
def setDefaults(defaults, dataset):
	"""set he default values in train dataset"""
	for rec in dataset:
		for i in range(len(rec)):
			if rec[i] == '':
				if i in defaults[rec[1]]:
					rec[i] = defaults[rec[1]][i]
			if i == 4:
				if rec[i] == 'male':
					rec[i] = 0
				else:
					rec[i] = 1
			if i == 11:
				if rec[i] == 'C':
					rec.extend([1,0,0])
				elif rec[i] == 'Q':
					rec.extend([0,1,0])
				else:
					rec.extend([0,0,1])
				
	

		
def defaultValues(stats, dataset):
	"""function to calculate default values of train and test data.
	It will update the train dataset and return the default vaules
	to be used for test data"""
	dtest = {}
	for i in range(2,12):
		dtest[i] = {}
		if i == 5 or i == 9:
			dtest[i] = [0,0]
			dtest[i][0] = stats[0][i][0] + stats[1][i][0]
			dtest[i][1] = stats[0][i][1] + stats[1][i][1]
			continue
		for key in stats[0][i].keys():
			dtest[i][key] = stats[0][i][key]
		for key in stats[1][i].keys():
			if key in dtest[i]:
				dtest[i][key] = dtest[i][key] + stats[1][i][key]
			else:
				dtest[i][key] = stats[1][i][key]
	stats[0] = maxavg(stats[0])
	stats[1] = maxavg(stats[1])
	dtest = maxavg(dtest)
	return dtest
	
#def main function
def main():
	if len(sys.argv)!= 3:
		print 'usage: %run ./preprocess.py filename headerFlag'
		sys.exit(1)
	#open the file
	f = open(sys.argv[1],'r')
	csvf = csv.reader(f, delimiter = ',')
	header = [range(11)]
	if sys.argv[2] == 'True':
		header = csvf.next()
	dataset = readData(csvf)
	stats = {}
	for cat in [0,1]:
		temp = {}
		for id in range(len(header)):
			if id == 5 or id == 9:
				temp[id] = [0,0]
			else:
				temp[id] = {}
		stats[cat] = temp
	ColMissingValues(dataset, header, stats)
	dtest = defaultValues(stats, dataset)
	print stats
	print 'dtest'
	print dtest
	setDefaults(stats, dataset)
	X = open('X.csv','w')
	csvX = csv.writer(X, delimiter = ',', quotechar = '"')
	y = open('y.csv','w')
	csvy = csv.writer(y, delimiter = ',', quotechar = '"')
	for rec in dataset:
		csvX.writerow([rec[2], rec[4], rec[5], rec[6], rec[7], rec[9], rec[12], rec[13], rec[14]])
		csvy.writerow([rec[1]])
	f.close()
	X.close()
	y.close()
	df = open('default.txt','w')
	json.dump(dtest, df)
	df.close()
		
		
		
#to call main function
if __name__ == '__main__':
	main()