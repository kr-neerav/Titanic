#############################################
#	this program preprocess the data		#
#	using scikit-learn modules				#
#############################################

from sklearn import preprocessing
import numpy
import sys
import csv
import json


def readData(csvf):
	"""to read all the contents of the file and store it in a list of lists"""
	dataset = []
	while(True):
		try:
			temp = csvf.next()
		except StopIteration:
			break
		dataset.append(temp)
	return dataset

	
	
def setDefaults(defaults, dataset):
	"""set he default values in train dataset"""
	for rec in dataset:
		for i in range(len(rec)):
			if rec[i] == '':
				if str(i+1) in defaults:
					rec[i] = defaults[str(i+1)]
			if i == 3:
				if rec[i] == 'male':
					rec[i] = 0
				else:
					rec[i] = 1
			if i == 10:
				if rec[i] == 'C':
					rec.extend([1,0,0])
				elif rec[i] == 'Q':
					rec.extend([0,1,0])
				else:
					rec.extend([0,0,1])
				
	

		
#def main function
def main():
	if len(sys.argv)!= 3:
		print 'usage: %run ./processtest.py filename headerFlag'
		sys.exit(1)
	#open the file
	f = open(sys.argv[1],'r')
	csvf = csv.reader(f, delimiter = ',')
	header = [range(11)]
	if sys.argv[2] == 'True':
		header = csvf.next()
	dataset = readData(csvf)
	dtest = json.load(open('default.txt','r'))
	print dtest
	setDefaults(dtest, dataset)
	X = open('Xt.csv','w')
	csvX = csv.writer(X, delimiter = ',', quotechar = '"')
	print dataset[1]
	raw_input()
	for rec in dataset:
		csvX.writerow([rec[1], rec[3], rec[4], rec[5], rec[6], rec[8], rec[11], rec[12], rec[13]])
	f.close()
	X.close()

		
		
		
#to call main function
if __name__ == '__main__':
	main()